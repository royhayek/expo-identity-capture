export { captureAndExtract, captureMultipleDocuments, detectDocumentType, validateExtractedData } from "./api/documentCapture";
import { captureAndExtract, captureMultipleDocuments, detectDocumentType, validateExtractedData } from "./api/documentCapture";
export { IdentityCaptureProvider } from "./components/IdentityCaptureProvider";
export { LocalizationManager, createLocalizedStrings } from "./localization";
export { arabicStrings } from "./localization/languages/arabic";
export { frenchStrings } from "./localization/languages/french";
export { FlowRules } from "./utils/flowRules";
export { ImageProcessor } from "./utils/imageProcessor";
export type { DocumentType, DocumentSide, OutputFormat, DocumentCaptureResult, SelfieCaptureResult, CaptureConfig, LocalizedStrings, CaptureCallbacks, DocumentCaptureOptions, SelfieCaptureOptions, FlowState, CaptureStep, CameraFrameGuide, } from "./types";
export type { VerifiedDocType, OcrField, ExtractedIdResult, DocumentTemplate, CaptureOptions, QualityMetrics } from "./types/extraction";
declare let DocumentScanner: any;
export { DocumentScanner };
export declare const IdentityCapture: {
    captureAndExtract: typeof captureAndExtract;
    captureMultipleDocuments: typeof captureMultipleDocuments;
    detectDocumentType: typeof detectDocumentType;
    validateExtractedData: typeof validateExtractedData;
};
