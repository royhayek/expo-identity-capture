export { DocumentCaptureAPI } from "./api/documentCapture";
export { SelfieCaptureAPI } from "./api/selfieCapture";
export { IdentityCaptureProvider } from "./components/IdentityCaptureProvider";
export { LocalizationManager, createLocalizedStrings } from "./localization";
export { arabicStrings } from "./localization/languages/arabic";
export { frenchStrings } from "./localization/languages/french";
export { FlowRules } from "./utils/flowRules";
export { ImageProcessor } from "./utils/imageProcessor";
export type { DocumentType, DocumentSide, OutputFormat, DocumentCaptureResult, SelfieCaptureResult, CaptureConfig, LocalizedStrings, CaptureCallbacks, DocumentCaptureOptions, SelfieCaptureOptions, FlowState, CaptureStep, CameraFrameGuide, } from "./types";
export declare const captureDocument: any;
export declare const captureSelfie: any;
export declare const IdentityCapture: {
    captureDocument: any;
    captureSelfie: any;
    isCapturing: () => boolean;
    cancelCurrentCapture: () => void;
};
