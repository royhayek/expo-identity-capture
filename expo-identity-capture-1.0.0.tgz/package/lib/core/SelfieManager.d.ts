import React from 'react';
export interface SelfieCaptureResult {
    originalImageUri: string;
    croppedImageUri: string;
}
interface SelfieManagerProps {
    visible: boolean;
    onCapture: (result: SelfieCaptureResult) => void;
    onCancel: () => void;
    enableFlash?: boolean;
}
export declare const SelfieManager: React.FC<SelfieManagerProps>;
export default SelfieManager;
