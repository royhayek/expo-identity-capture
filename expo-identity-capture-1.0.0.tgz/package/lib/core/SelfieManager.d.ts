import React from 'react';
interface SelfieManagerProps {
    visible: boolean;
    onCapture: (imageUri: string) => void;
    onCancel: () => void;
    enableFlash?: boolean;
}
export declare const SelfieManager: React.FC<SelfieManagerProps>;
export default SelfieManager;
