import { ExtractedIdResult, CaptureOptions } from "../types/extraction";
export declare class DocumentExtractor {
    private static templates;
    private static readonly MIN_OCR_CONFIDENCE;
    private static readonly MIN_TEXT_LENGTH;
    /**
     * Main API function: Capture and extract document data
     */
    static captureAndExtract(options?: CaptureOptions): Promise<ExtractedIdResult>;
    /**
     * Enhanced capture with comprehensive quality control
     */
    private static captureWithAdvancedQuality;
    /**
     * Advanced document type detection using multiple methods
     */
    private static detectDocumentTypeAdvanced;
    /**
     * Comprehensive text analysis using ML Kit with fallbacks
     */
    private static performTextAnalysis;
    /**
     * Preprocess Arabic text for better recognition
     */
    private static preprocessArabicText;
    /**
     * Calculate text confidence based on OCR results
     */
    private static calculateTextConfidence;
    /**
     * Analyze content to determine document type
     */
    private static analyzeContentForDocType;
    /**
     * Enhanced MRZ presence detection
     */
    private static detectMRZPresenceAdvanced;
    /**
     * Score how likely a line is to be an MRZ line
     */
    private static scoreMRZLikeLine;
    /**
     * Check if document type has MRZ
     */
    private static hasMRZ;
    /**
     * Extract MRZ-based documents with enhanced processing
     */
    private static extractMRZDocument;
    /**
     * Enhanced OCR-based document extraction
     */
    private static extractOCRDocument;
    /**
     * Advanced field extraction with multiple strategies
     */
    private static extractFieldsAdvanced;
    /**
     * Get field extraction patterns for document type
     */
    private static getFieldPatterns;
    /**
     * Extract fields using pattern matching
     */
    private static extractUsingPatterns;
    /**
     * Extract fields using contextual analysis
     */
    private static extractUsingContext;
    /**
     * Extract fields using template regions (basic implementation)
     */
    private static extractUsingTemplate;
    /**
     * Post-process extracted fields
     */
    private static postProcessFields;
    /**
     * Utility methods for field processing
     */
    private static isCommonWord;
    private static normalizeDateFormat;
    /**
     * Convert Arabic-Indic numerals to Western numerals
     */
    private static convertArabicNumerals;
    private static normalizeDocumentNumber;
    private static normalizeArabicText;
    private static normalizeLatinName;
    private static normalizeSex;
    private static normalizeNationality;
    /**
     * Create OCR field with standardized format
     */
    private static createOcrField;
    /**
     * Enhanced template loading with validation
     */
    private static loadTemplateAdvanced;
    /**
     * Enhanced image quality assessment
     */
    private static assessImageQualityAdvanced;
}
