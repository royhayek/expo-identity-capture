import { ExtractedIdResult, CaptureOptions } from "../types/extraction";
export declare class DocumentExtractor {
    private static templates;
    private static readonly MIN_OCR_CONFIDENCE;
    private static readonly MIN_TEXT_LENGTH;
    /**
     * Main API function: Capture and extract document data
     */
    static captureAndExtract(options?: CaptureOptions): Promise<ExtractedIdResult>;
    /**
     * Alternative capture method using custom OpenCV-based document capture
     */
    static captureAndExtractWithCustomCamera(options?: CaptureOptions): Promise<ExtractedIdResult>;
    /**
     * Enhanced capture with comprehensive quality control
     */
    private static captureWithAdvancedQuality;
    /**
     * Advanced document type detection using multiple methods
     */
    private static detectDocumentTypeAdvanced;
    /**
     * Comprehensive text analysis using ML Kit with fallbacks
     */
    private static performTextAnalysis;
    /**
     * Preprocess Arabic text for better recognition
     */
    private static preprocessArabicText;
    /**
     * Analyze Arabic text quality for debugging and optimization
     */
    private static analyzeArabicTextQuality;
    /**
     * Calculate text confidence based on OCR results
     */
    private static calculateTextConfidence;
    /**
     * Analyze content to determine document type
     */
    private static analyzeContentForDocType;
    /**
     * Validate that the detected document type matches the expected type
     */
    private static validateDocumentType;
    /**
     * Perform enhanced document detection with detailed analysis
     */
    private static performEnhancedDocumentDetection;
    /**
     * Check for distinguishing features between document types
     */
    private static checkDistinguishingFeatures;
    /**
     * Generate user-friendly error message for document type mismatch
     */
    private static generateDocumentMismatchError;
    /**
     * Enhanced OCR-based document extraction
     */
    private static extractOCRDocument;
    /**
     * Advanced field extraction with multiple strategies
     */
    private static extractFieldsAdvanced;
    /**
     * Get field extraction patterns for document type
     */
    private static getFieldPatterns;
    /**
     * Extract fields using pattern matching
     */
    private static extractUsingPatterns;
    /**
     * Extract fields using contextual analysis
     */
    private static extractUsingContext;
    /**
     * Extract fields using template regions with coordinate-based text analysis
     */
    private static extractUsingTemplate;
    /**
     * Convert normalized template coordinates (0-1) to pixel coordinates
     */
    private static convertToPixelCoordinates;
    /**
     * Extract text from a specific region using spatial analysis
     */
    private static extractTextFromRegion;
    /**
     * Find text within a specific region using spatial analysis
     */
    private static findTextInRegion;
    /**
     * Get keywords that typically appear near specific fields
     */
    private static getFieldKeywords;
    /**
     * Find text candidates near specific keywords
     */
    private static findTextCandidatesNearKeywords;
    /**
     * Extract value from a line (after colon, dash, or keyword)
     */
    private static extractValueFromLine;
    /**
     * Select the best candidate based on field type expectations
     */
    private static selectBestCandidate;
    /**
     * Extract text by position analysis
     */
    private static extractByPosition;
    /**
     * Extract text using pattern matching for specific field types
     */
    private static extractByPattern;
    /**
     * Check if a value is valid for a specific field type
     */
    private static isValidForField;
    /**
     * Calculate confidence score for region-extracted text
     */
    private static calculateRegionConfidence;
    /**
     * Apply field-specific processing to extracted values
     */
    private static processFieldValue;
    /**
     * Post-process extracted fields
     */
    private static postProcessFields;
    /**
     * Utility methods for field processing
     */
    private static isCommonWord;
    private static normalizeDateFormat;
    /**
     * Convert Arabic-Indic numerals to Western numerals
     */
    private static convertArabicNumerals;
    private static normalizeDocumentNumber;
    private static normalizeArabicText;
    private static normalizeLatinName;
    private static normalizeSex;
    private static normalizeNationality;
    /**
     * Create OCR field with standardized format
     */
    private static createOcrField;
    /**
     * Enhanced template loading with validation
     */
    private static loadTemplateAdvanced;
    /**
     * Enhanced image quality assessment
     */
    private static assessImageQualityAdvanced;
    /**
     * Get appropriate passport template based on detected version
     */
    private static getPassportTemplate;
    /**
     * Template for Lebanese old passport (based on lebanese-old-passport.jpg)
     * Layout analysis from image:
     * - Photo on left side (0.02, 0.15, 0.28, 0.70)
     * - Document number top right (RL 4186499)
     * - First name and surname in center-right area
     * - Date fields in middle-right
     * - MRZ at bottom (2 lines)
     */
    private static getOldPassportTemplate;
    /**
     * Template for Lebanese passport (based on lebanese-passport-two-pages.jpg)
     * Layout analysis from real Lebanese passport showing both pages vertically:
     * - Left page: Stamps and visa area
     * - Right page: Information page with photo on left, data fields on right
     * - All coordinates are for the information page (right side)
     * - Document: LR19276166, Name: EL HAYEK ROY NICOLAS, DOB: 27 09 1996
     * - MRZ at bottom (2 lines)
     */
    private static getNewPassportTemplate;
    /**
     * Template for Lebanese Civil ID Front (based on lebanese-civil-id-front.jpg)
     * Layout analysis from image:
     * - Photo on left side (0.05, 0.20, 0.35, 0.75)
     * - All text fields in Arabic on right side
     * - Document number at bottom in special format
     */
    private static getCivilIdTemplate;
    /**
     * Template for Lebanese Residence Permit (based on residence-permit-front.jpg)
     * Layout analysis from image:
     * - Photo on left side (0.05, 0.25, 0.25, 0.75)
     * - Document number top right
     * - Name fields in center
     * - Date fields at bottom
     */
    private static getResidencePermitTemplate;
    /**
     * Validate that the captured image has a proper rectangular shape
     * This helps ensure document scanner properly detected and cropped the document
     */
    private static validateRectangularShape;
    /**
     * Validate that image file exists and is accessible
     */
    private static validateImageFile;
    /**
     * Get image dimensions using available methods
     */
    private static getImageDimensions;
    /**
     * Validate aspect ratio against common document ratios
     */
    private static validateAspectRatio;
    /**
     * Validate minimum image dimensions
     */
    private static validateMinimumDimensions;
    /**
     * Perform advanced shape validation using image analysis
     */
    private static performAdvancedShapeValidation;
    /**
     * Test rectangular shape validation with sample images from assets folder
     * This method can be used for development/testing purposes
     */
    static testValidationWithAssets(): Promise<void>;
    /**
     * Test method to analyze the exact dimensions and aspect ratio of the real passport image
     */
    static analyzePassportImageDimensions(): Promise<void>;
    /**
     * Get validation metrics for a given image
     * Useful for debugging and fine-tuning validation parameters
     */
    static getValidationMetrics(imageUri: string): Promise<{
        fileExists: boolean;
        dimensions?: {
            width: number;
            height: number;
        };
        aspectRatio?: number;
        validAspectRatio?: boolean;
        validDimensions?: boolean;
        shapeValidation?: {
            isValid: boolean;
            reason?: string;
        };
    }>;
    /**
     * Test template-based extraction with sample images
     * This method can be used for development/testing purposes
     */
    static testTemplateExtraction(): Promise<void>;
    /**
     * Test document type validation with cross-document scenarios
     * This method can be used for development/testing purposes
     */
    static testDocumentValidation(): Promise<void>;
}
