import React from 'react';
import { VerifiedDocType } from '../types/extraction';
interface CameraManagerProps {
    visible: boolean;
    docType: VerifiedDocType;
    onCapture: (imageUri: string) => void;
    onCancel: () => void;
    disableDetection?: boolean;
    enableFlash?: boolean;
}
/**
 * Camera Manager Component
 * Handles the presentation of the custom camera view in a modal
 */
export declare const CameraManager: React.FC<CameraManagerProps>;
/**
 * Global camera manager instance
 * This allows us to show the camera from non-React contexts
 */
declare class GlobalCameraManager {
    private static instance;
    private captureResolver;
    private captureRejecter;
    static getInstance(): GlobalCameraManager;
    /**
     * Show camera and wait for result
     * This is handled by the CameraManager React component
     */
    showCamera(docType: VerifiedDocType, disableDetection?: boolean, enableFlash?: boolean): Promise<{
        imageUri: string;
        cancelled: boolean;
    }>;
    /**
     * Handle capture result from camera
     */
    handleCapture(imageUri: string): void;
    /**
     * Handle camera cancellation
     */
    handleCancel(): void;
}
export default GlobalCameraManager;
