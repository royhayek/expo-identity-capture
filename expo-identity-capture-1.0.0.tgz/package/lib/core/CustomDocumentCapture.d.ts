import { VerifiedDocType } from "../types/extraction";
/**
 * Custom Document Capture using OpenCV and Vision Camera
 * This module provides a custom document scanning solution with:
 * - Complete UI control (Cancel + Flash only)
 * - Single capture mode
 * - Real-time document detection
 * - Perspective correction
 * - OpenCV-based edge detection
 */
export interface CustomCaptureOptions {
    docHint: VerifiedDocType;
    enableFlash?: boolean;
    quality?: number;
    maxRetries?: number;
}
export interface CustomCaptureResult {
    originalImageUri: string;
    processedImageUri: string;
    detectedCorners: {
        x: number;
        y: number;
    }[];
    captureTimestamp: string;
}
export declare class CustomDocumentCapture {
    private static instance;
    /**
     * Get singleton instance
     */
    static getInstance(): CustomDocumentCapture;
    /**
     * Start custom document capture with OpenCV-based detection
     */
    captureDocument(options: CustomCaptureOptions): Promise<CustomCaptureResult>;
    /**
     * Initialize camera with Vision Camera
     */
    private initializeCamera;
    /**
     * Open camera view for document capture
     */
    private openCameraView;
    /**
     * Check if detected corners are stable between frames
     */
    private areCornersStable;
    /**
     * Process captured image with OpenCV
     */
    private processWithOpenCV;
    /**
     * Detect document contours using OpenCV
     */
    private detectDocumentContours;
    /**
     * Load image as buffer for OpenCV processing
     */
    private loadImageAsBuffer;
    /**
     * Apply perspective correction to document
     */
    private applyPerspectiveCorrection;
    /**
     * Validate document shape based on type
     */
    private validateDocumentShape;
    /**
     * Check if detected shape is a vertical rectangle
     */
    private isVerticalRectangle;
    /**
     * Check if detected shape is a horizontal rectangle
     */
    private isHorizontalRectangle;
}
export default CustomDocumentCapture;
