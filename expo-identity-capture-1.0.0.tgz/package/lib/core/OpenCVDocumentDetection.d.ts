/**
 * OpenCV Document Detection Module
 * Handles real-time document detection, edge detection, and perspective correction
 * This module serves as a bridge to OpenCV functionality when available
 */
import { VerifiedDocType } from "../types/extraction";
export interface DetectedDocument {
    corners: {
        x: number;
        y: number;
    }[];
    confidence: number;
    area: number;
    aspectRatio: number;
    isValidShape: boolean;
}
export interface ProcessingResult {
    originalImageUri: string;
    processedImageUri: string;
    detectedDocument: DetectedDocument;
    processingTime: number;
}
export declare class OpenCVDocumentDetection {
    private static readonly MIN_CONTOUR_AREA;
    private static readonly APPROX_POLY_EPSILON;
    private static readonly CANNY_THRESHOLD_1;
    private static readonly CANNY_THRESHOLD_2;
    /**
     * Process camera frame for real-time document detection
     * Note: This will use native OpenCV when react-native-fast-opencv is properly configured
     * Currently falls back to JS implementation in DocumentDetectionProcessor
     */
    static processFrame(imageBuffer: ArrayBuffer, docType: VerifiedDocType): Promise<DetectedDocument | null>;
    /**
     * Apply perspective correction to captured image
     */
    static applyPerspectiveCorrection(imageUri: string, corners: {
        x: number;
        y: number;
    }[], docType: VerifiedDocType): Promise<ProcessingResult>;
    /**
     * Calculate target dimensions for perspective correction
     */
    private static getTargetDimensions;
    /**
     * Calculate distance between two points
     */
    private static calculateDistance;
    /**
     * Calculate area of polygon defined by corners
     */
    private static calculateArea;
    /**
     * Validate document shape based on type and aspect ratio
     */
    static validateDocumentShape(corners: {
        x: number;
        y: number;
    }[], docType: VerifiedDocType): boolean;
}
export default OpenCVDocumentDetection;
