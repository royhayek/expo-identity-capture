/**
 * Comprehensive test validation suite for document extraction
 * This provides testing utilities and validation methods
 */
export interface TestResult {
    success: boolean;
    message: string;
    details?: any;
    duration: number;
}
export interface TestSuite {
    name: string;
    tests: TestCase[];
}
export interface TestCase {
    name: string;
    description: string;
    testFunction: () => Promise<TestResult>;
}
/**
 * Test validation utilities for the document extraction system
 */
export declare class TestValidation {
    /**
     * Create test suite for OCR document extraction
     */
    static createOCRTestSuite(): TestSuite;
    /**
     * Run a complete test suite
     */
    static runTestSuite(suite: TestSuite): Promise<void>;
    /**
     * Run all available test suites
     */
    static runAllTests(): Promise<void>;
    /**
     * Performance benchmark for document extraction
     */
    static benchmarkExtraction(imageUri: string, iterations?: number): Promise<void>;
}
