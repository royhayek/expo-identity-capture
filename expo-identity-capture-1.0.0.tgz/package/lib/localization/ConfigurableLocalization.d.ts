import { VerifiedDocType } from '../types/extraction';
import { LocalizationConfig, DocumentLabels, DocumentInstructions, AlertMessages } from '../types/config';
export declare const DEFAULT_STRINGS: {
    en: {
        documentLabels: DocumentLabels;
        instructions: DocumentInstructions;
        alerts: AlertMessages;
        ui: {
            capture: string;
            retake: string;
            cancel: string;
            done: string;
            loading: string;
            error: string;
            flashOn: string;
            flashOff: string;
            back: string;
            front: string;
            selfie_instruction: string;
        };
    };
    ar: {
        documentLabels: DocumentLabels;
        instructions: DocumentInstructions;
        alerts: AlertMessages;
        ui: {
            capture: string;
            retake: string;
            cancel: string;
            done: string;
            loading: string;
            error: string;
            flashOn: string;
            flashOff: string;
            back: string;
            front: string;
            selfie_instruction: string;
        };
    };
    fr: {
        documentLabels: DocumentLabels;
        instructions: DocumentInstructions;
        alerts: AlertMessages;
        ui: {
            capture: string;
            retake: string;
            cancel: string;
            done: string;
            loading: string;
            error: string;
            flashOn: string;
            flashOff: string;
            back: string;
            front: string;
            selfie_instruction: string;
        };
    };
};
export declare class ConfigurableLocalizationManager {
    private config;
    constructor(config?: LocalizationConfig);
    updateConfig(config: LocalizationConfig): void;
    getCurrentLanguage(): string;
    getDocumentLabel(docType: VerifiedDocType): string;
    getInstructionText(docType: VerifiedDocType): string;
    getAlertMessage(key: keyof AlertMessages): string;
    getUIText(key: string): string;
    getAvailableLanguages(): string[];
    isLanguageSupported(language: string): boolean;
    getBestMatchingLanguage(preferredLanguage: string): string;
}
export declare const defaultLocalizationManager: ConfigurableLocalizationManager;
