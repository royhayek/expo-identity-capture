import { LocalizedStrings } from '../types';
export declare class LocalizationManager {
    private static instance;
    private strings;
    private constructor();
    static getInstance(): LocalizationManager;
    setStrings(customStrings: Partial<LocalizedStrings>): void;
    getStrings(): LocalizedStrings;
    getString(key: keyof LocalizedStrings): string;
    static mergeStrings(customStrings?: Partial<LocalizedStrings>): LocalizedStrings;
}
export declare const localizationManager: LocalizationManager;
export declare const createLocalizedStrings: (customStrings?: Partial<LocalizedStrings>) => LocalizedStrings;
