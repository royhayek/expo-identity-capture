import { LocalizedStrings } from '../../types';
export declare const frenchStrings: LocalizedStrings;
