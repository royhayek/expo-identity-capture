import { LocalizedStrings } from '../../types';
export declare const arabicStrings: LocalizedStrings;
