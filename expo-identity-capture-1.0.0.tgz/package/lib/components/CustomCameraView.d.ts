import React from "react";
import { VerifiedDocType } from "../types/extraction";
interface CustomCameraViewProps {
    docType: VerifiedDocType;
    onCapture: (imageUri: string) => void;
    onCancel: () => void;
    disableDetection?: boolean;
    enableFlash?: boolean;
}
export declare const CustomCameraView: React.FC<CustomCameraViewProps>;
export default CustomCameraView;
