import React from "react";
import { DocumentType, DocumentSide, CaptureConfig } from "../types";
interface CameraScreenProps {
    documentType?: DocumentType;
    documentSide?: DocumentSide;
    isSelfie?: boolean;
    config: CaptureConfig;
    onCapture: (imageUri: string) => void;
    onCancel: () => void;
    onError: (error: Error) => void;
}
export declare const CameraScreen: React.FC<CameraScreenProps>;
export {};
