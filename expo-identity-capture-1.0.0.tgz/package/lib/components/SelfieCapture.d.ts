import React from "react";
interface SelfieCaptureProps {
    onCapture: (imageUri: string) => void;
    onCancel: () => void;
    enableFlash?: boolean;
}
export declare const ModernSelfieCapture: React.FC<SelfieCaptureProps>;
interface OriginalSelfieCaptureProps {
    visible: boolean;
    options: {
        onSuccess?: (result: {
            image: string;
            capturedAt: string;
        }) => void;
        onCancel?: () => void;
        onError?: (error: Error) => void;
    };
    onClose: () => void;
}
export declare const SelfieCapture: React.FC<OriginalSelfieCaptureProps>;
export default ModernSelfieCapture;
