import React from 'react';
import { SelfieCaptureOptions } from '../types';
interface SelfieCaptureProps {
    visible: boolean;
    options: SelfieCaptureOptions;
    onClose: () => void;
}
export declare const SelfieCapture: React.FC<SelfieCaptureProps>;
export {};
