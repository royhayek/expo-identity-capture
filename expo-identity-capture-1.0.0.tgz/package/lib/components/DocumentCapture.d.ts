import React from 'react';
import { DocumentCaptureOptions } from '../types';
interface DocumentCaptureProps {
    visible: boolean;
    options: DocumentCaptureOptions;
    onClose: () => void;
}
export declare const DocumentCapture: React.FC<DocumentCaptureProps>;
export {};
