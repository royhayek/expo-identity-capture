import React from 'react';
import { IdentityCaptureConfig } from '../types/config';
interface IdentityCaptureProviderProps {
    children: React.ReactNode;
    config?: IdentityCaptureConfig;
}
export declare const IdentityCaptureProvider: React.FC<IdentityCaptureProviderProps>;
export {};
