import React from 'react';
interface IdentityCaptureProviderProps {
    children: React.ReactNode;
}
export declare const IdentityCaptureProvider: React.FC<IdentityCaptureProviderProps>;
export {};
