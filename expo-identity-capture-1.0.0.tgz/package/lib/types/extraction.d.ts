export type VerifiedDocType = 'passport' | 'residence_permit' | 'civil_id' | 'army_card' | 'civil_register';
export interface OcrField {
    value: string | null;
    confidence: number;
    source: 'mrz' | 'ocr' | 'derived';
}
export interface ExtractedIdResult {
    docType: VerifiedDocType;
    originalImageUri: string;
    croppedImageUri: string;
    crops?: Record<string, string>;
    fields: {
        documentNumber?: OcrField;
        fullNameArabic?: OcrField;
        fullNameLatin?: OcrField;
        givenNames?: OcrField;
        surname?: OcrField;
        dateOfBirth?: OcrField;
        sex?: OcrField;
        nationality?: OcrField;
        placeOfBirth?: OcrField;
        dateOfIssue?: OcrField;
        dateOfExpiry?: OcrField;
        motherName?: OcrField;
        fatherName?: OcrField;
    };
    mrz?: {
        raw: string;
        type: 'TD1' | 'TD2' | 'TD3';
        checks: {
            documentNumber: boolean;
            dob: boolean;
            expiry: boolean;
            composite: boolean;
        };
    };
    quality: {
        blurScore: number;
        brightness: number;
        glareDetected: boolean;
    };
}
export interface DocumentTemplate {
    docType: string;
    size: {
        w: number;
        h: number;
    };
    fields: Record<string, {
        x: number;
        y: number;
        w: number;
        h: number;
    }>;
}
export interface CaptureOptions {
    docHint?: VerifiedDocType;
    enableQualityCheck?: boolean;
    confidenceThreshold?: number;
    saveProcessedImages?: boolean;
    useCustomCapture?: boolean;
    enableFlash?: boolean;
}
export interface QualityMetrics {
    blurScore: number;
    brightness: number;
    glareDetected: boolean;
    edgesDetected: boolean;
    isAcceptable: boolean;
}
