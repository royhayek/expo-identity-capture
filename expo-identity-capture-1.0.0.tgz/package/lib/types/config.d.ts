import { VerifiedDocType } from './extraction';
export interface ThemeColors {
    primary?: string;
    secondary?: string;
    danger?: string;
    warning?: string;
    background?: string;
    surface?: string;
    overlay?: string;
    text?: {
        primary?: string;
        secondary?: string;
        disabled?: string;
        inverse?: string;
    };
    border?: {
        default?: string;
        detected?: string;
        frame?: string;
    };
    progress?: {
        gradient?: string[];
        background?: string;
    };
}
export interface TypographyConfig {
    fonts?: {
        regular?: string;
        medium?: string;
        semibold?: string;
        bold?: string;
    };
    sizes?: {
        xs?: number;
        sm?: number;
        base?: number;
        lg?: number;
        xl?: number;
        xxl?: number;
    };
    lineHeights?: {
        tight?: number;
        normal?: number;
        relaxed?: number;
    };
    weights?: {
        normal?: string;
        medium?: string;
        semibold?: string;
        bold?: string;
    };
}
export interface FrameDimensions {
    top?: string;
    left?: string;
    right?: string;
    height?: string;
}
export interface LayoutConfig {
    frame?: Partial<Record<VerifiedDocType, FrameDimensions>>;
    borderRadius?: number;
    buttons?: {
        capture?: {
            width?: number;
            height?: number;
        };
        header?: {
            width?: number;
            height?: number;
        };
    };
    spacing?: {
        xs?: number;
        sm?: number;
        md?: number;
        lg?: number;
        xl?: number;
    };
    overlay?: {
        opacity?: number;
    };
}
export interface AnimationConfig {
    progress?: {
        duration?: number;
        easing?: 'linear' | 'ease' | 'easeIn' | 'easeOut' | 'easeInOut';
    };
    modal?: {
        type?: 'slide' | 'fade' | 'none';
        duration?: number;
    };
    transitions?: {
        enableAnimations?: boolean;
        reducedMotion?: boolean;
    };
}
export type DocumentLabels = {
    [K in VerifiedDocType]?: string;
};
export type DocumentInstructions = {
    [K in VerifiedDocType]?: string;
};
export interface AlertMessages {
    captureSuccess?: string;
    captureFailed?: string;
    ocrValidationFailed?: string;
    processingTimeout?: string;
    cameraPermissionDenied?: string;
    cameraNotAvailable?: string;
    documentCaptured?: string;
    retakePhoto?: string;
    useThisPhoto?: string;
}
export interface LocalizationConfig {
    language?: 'en' | 'ar' | 'fr' | string;
    customStrings?: {
        [language: string]: {
            documentLabels?: DocumentLabels;
            instructions?: DocumentInstructions;
            alerts?: AlertMessages;
            ui?: {
                capture?: string;
                retake?: string;
                cancel?: string;
                done?: string;
                loading?: string;
                error?: string;
                flashOn?: string;
                flashOff?: string;
                back?: string;
                front?: string;
            };
        };
    };
}
export interface DetectionConfig {
    ocr?: {
        timeout?: number;
        throttleInterval?: number;
        minTextLength?: number;
        consecutiveFailureThreshold?: number;
        confidenceThresholds?: {
            high?: number;
            medium?: number;
            low?: number;
        };
    };
    vision?: {
        confidenceThreshold?: number;
        aspectRatioTolerance?: number;
        frameSizeConstraints?: {
            min?: number;
            max?: number;
        };
        stabilityThreshold?: number;
        edgeMargin?: number;
    };
    processing?: {
        frameSkipCount?: number;
        maxRetries?: number;
        processingTimeout?: number;
    };
}
export interface CameraConfig {
    defaultDevice?: 'front' | 'back';
    flash?: {
        enabled?: boolean;
        default?: 'on' | 'off' | 'auto';
    };
    photo?: {
        quality?: number;
        format?: 'jpeg' | 'png';
        enableShutterSound?: boolean;
    };
    permissions?: {
        requestOnMount?: boolean;
        showPermissionAlert?: boolean;
    };
}
export interface ImageProcessingConfig {
    quality?: number;
    maxDimensions?: {
        width?: number;
        height?: number;
    };
    format?: 'jpeg' | 'png';
    compression?: {
        enabled?: boolean;
        quality?: number;
    };
    output?: 'uri' | 'base64';
}
export interface FieldPosition {
    x: number;
    y: number;
    w: number;
    h: number;
    type?: 'text' | 'number' | 'date' | 'mrz';
    validation?: {
        pattern?: RegExp;
        minLength?: number;
        maxLength?: number;
        required?: boolean;
    };
}
export interface DocumentTemplate {
    docType: VerifiedDocType;
    size?: {
        w: number;
        h: number;
    };
    aspectRatio?: number;
    fields?: Record<string, FieldPosition>;
    validation?: {
        requiredFields?: string[];
        optionalFields?: string[];
    };
}
export interface ValidationConfig {
    keywords?: Partial<Record<VerifiedDocType, {
        specific?: string[];
        general?: string[];
        excludePatterns?: RegExp[];
    }>>;
    textQuality?: {
        minLength?: number;
        minAlphanumericRatio?: number;
        debugPatternThreshold?: number;
    };
    matching?: {
        requiredSpecificMatches?: number;
        requiredGeneralMatches?: number;
        caseSensitive?: boolean;
    };
}
export interface IdentityCaptureConfig {
    theme?: {
        colors?: ThemeColors;
        typography?: TypographyConfig;
        layout?: LayoutConfig;
        animation?: AnimationConfig;
    };
    localization?: LocalizationConfig;
    behavior?: {
        detection?: DetectionConfig;
        camera?: CameraConfig;
        imageProcessing?: ImageProcessingConfig;
    };
    documents?: {
        templates?: Record<VerifiedDocType, DocumentTemplate>;
        validation?: ValidationConfig;
    };
}
export declare const DEFAULT_CONFIG: Required<IdentityCaptureConfig>;
