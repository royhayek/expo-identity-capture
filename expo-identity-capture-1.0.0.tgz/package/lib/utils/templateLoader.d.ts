import { DocumentTemplate, VerifiedDocType } from '../types/extraction';
/**
 * Template loader utility for loading document templates from JSON files
 */
export declare class TemplateLoader {
    private static templates;
    /**
     * Load template for a specific document type
     */
    static loadTemplate(docType: VerifiedDocType): Promise<DocumentTemplate | null>;
    /**
     * Process template data from JSON to ensure proper typing
     */
    private static processTemplateData;
    /**
     * Fallback passport template (could be enhanced with version detection)
     */
    private static getPassportTemplate;
    /**
     * Fallback residence permit template
     */
    private static getResidencePermitFallback;
    /**
     * Get all available template types
     */
    static getAvailableTemplateTypes(): VerifiedDocType[];
    /**
     * Check if template exists for document type
     */
    static hasTemplate(docType: VerifiedDocType): boolean;
    /**
     * Clear template cache
     */
    static clearCache(): void;
}
