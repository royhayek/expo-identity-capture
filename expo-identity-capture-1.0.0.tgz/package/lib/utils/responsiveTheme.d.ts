export declare const responsiveScale: {
    width: (size: number) => number;
    height: (size: number) => number;
    font: (size: number, factor?: number) => number;
    moderate: (size: number, factor?: number) => number;
};
export declare const useResponsiveTheme: () => {
    typography: {
        sizes: {
            xs: number;
            sm: number;
            base: number;
            lg: number;
            xl: number;
            xxl: number;
        };
        lineHeights: {
            tight: number;
            normal: number;
            relaxed: number;
        };
        fonts: {
            regular?: string;
            medium?: string;
            semibold?: string;
            bold?: string;
        };
        weights: {
            normal?: string;
            medium?: string;
            semibold?: string;
            bold?: string;
        };
    };
    spacing: {
        xs: number;
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    layout: {
        borderRadius: number;
        buttons: {
            capture: {
                width: number;
                height: number;
            };
            header: {
                width: number;
                height: number;
            };
        };
        frame: Partial<Record<import("..").VerifiedDocType, import("..").FrameDimensions>>;
        overlay: {
            opacity?: number;
        };
    };
    colors: import("..").ThemeColors;
    animation: import("..").AnimationConfig;
};
export declare const getResponsiveFontSize: (size: "xs" | "sm" | "base" | "lg" | "xl" | "xxl", customSize?: number) => number;
export declare const getResponsiveSpacing: (size: "xs" | "sm" | "md" | "lg" | "xl", customSize?: number) => number;
export declare const getResponsiveWidth: (size: number) => number;
export declare const getResponsiveHeight: (size: number) => number;
export declare const getResponsiveModerate: (size: number, factor?: number) => number;
export declare const RESPONSIVE_VALUES: {
    captureButton: {
        width: number;
        height: number;
    };
    headerButton: {
        width: number;
        height: number;
    };
    borderRadius: {
        small: number;
        medium: number;
        large: number;
    };
    margin: {
        xs: number;
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    padding: {
        xs: number;
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    fontSize: {
        xs: number;
        sm: number;
        base: number;
        lg: number;
        xl: number;
        xxl: number;
    };
    iconSize: {
        small: number;
        medium: number;
        large: number;
    };
};
export default RESPONSIVE_VALUES;
