export interface OCRResult {
    text: string;
    confidence: number;
    blocks?: any[];
    processingTime: number;
}
export interface OCROptions {
    language?: string;
    enableOCR?: boolean;
    timeout?: number;
}
/**
 * Comprehensive OCR processor with multiple engine support and fallbacks
 */
export declare class OCRProcessor {
    private static readonly DEFAULT_TIMEOUT;
    private static readonly MAX_RETRIES;
    /**
     * Extract text from image using best available OCR engine
     */
    static extractText(imageUri: string, options?: OCROptions): Promise<OCRResult>;
    /**
     * Extract text using Google ML Kit with retries
     */
    private static extractWithMLKit;
    /**
     * Calculate ML Kit confidence based on result quality
     */
    private static calculateMLKitConfidence;
    /**
     * Validate OCR result quality
     */
    static validateResult(result: OCRResult): boolean;
    /**
     * Clean and preprocess OCR text
     */
    static preprocessText(text: string): string;
}
