import { LocalizedStrings } from '../types';
export declare const defaultStrings: LocalizedStrings;
