import { CaptureConfig } from '../types';
import { DocumentTemplate } from '../types/extraction';
export interface ProcessImageOptions {
    uri: string;
    config: CaptureConfig;
}
export interface CropImageOptions {
    uri: string;
    cropX: number;
    cropY: number;
    cropWidth: number;
    cropHeight: number;
    quality?: number;
}
export interface DocumentCorners {
    topLeft: {
        x: number;
        y: number;
    };
    topRight: {
        x: number;
        y: number;
    };
    bottomLeft: {
        x: number;
        y: number;
    };
    bottomRight: {
        x: number;
        y: number;
    };
}
export declare class ImageProcessor {
    static processImage({ uri, config }: ProcessImageOptions): Promise<string>;
    static compressImage(uri: string, quality?: number): Promise<string>;
    /**
     * Crop image based on normalized coordinates (0-1)
     */
    static cropImage(options: CropImageOptions): Promise<string>;
    /**
     * Get image dimensions
     */
    private static getImageInfo;
    /**
     * Crop document from detected corners using perspective correction
     */
    static cropDocumentFromCorners(uri: string, corners: DocumentCorners, quality?: number): Promise<string>;
    /**
     * Crop document using frame-based detection (fallback method)
     */
    static cropDocumentFromFrame(uri: string, frameConfig: {
        top: string;
        left: string;
        right: string;
        height: string;
    }, quality?: number): Promise<string>;
    /**
     * Calculate frame boundaries from template field positions
     */
    static calculateTemplateFrameBounds(template: DocumentTemplate): {
        top: string;
        left: string;
        right: string;
        height: string;
    };
    /**
     * Crop document using template-based frame calculation
     */
    static cropDocumentFromTemplate(uri: string, template: DocumentTemplate, quality?: number): Promise<string>;
    static getTimestamp(): string;
}
