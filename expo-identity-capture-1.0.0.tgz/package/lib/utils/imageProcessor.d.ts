import { CaptureConfig } from '../types';
export interface ProcessImageOptions {
    uri: string;
    config: CaptureConfig;
}
export declare class ImageProcessor {
    static processImage({ uri, config }: ProcessImageOptions): Promise<string>;
    static compressImage(uri: string, quality?: number): Promise<string>;
    static getTimestamp(): string;
}
