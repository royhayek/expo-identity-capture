import { DocumentType, CaptureStep, FlowState } from '../types';
export declare class FlowRules {
    static getRequiredSteps(documentType: DocumentType, flowState: FlowState): CaptureStep[];
    static getNextRequiredDocument(flowState: FlowState): DocumentType | null;
    static isFlowComplete(documentType: DocumentType, flowState: FlowState): boolean;
    static validateDocumentCapture(documentType: DocumentType, side?: string): boolean;
    static getDocumentSides(documentType: DocumentType): string[];
}
