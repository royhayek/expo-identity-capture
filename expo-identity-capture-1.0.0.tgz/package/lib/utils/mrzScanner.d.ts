export interface PassportMRZData {
    documentType: string;
    issuingCountry: string;
    lastName: string;
    firstName: string;
    passportNumber: string;
    nationality: string;
    dateOfBirth: string;
    sex: string;
    expirationDate: string;
    personalNumber?: string;
    checkDigits: {
        passportNumber: string;
        dateOfBirth: string;
        expirationDate: string;
        personalNumber?: string;
        composite: string;
    };
    valid: boolean;
    validationDetails: {
        passportNumberValid: boolean;
        dateOfBirthValid: boolean;
        expirationDateValid: boolean;
        personalNumberValid: boolean;
        compositeValid: boolean;
        formatValid: boolean;
    };
}
export declare class MRZScanner {
    /**
     * Create MRZ frame processor for Vision Camera
     */
    static createMRZFrameProcessor(onMRZDetected: (mrz: PassportMRZData) => void): import("react-native-vision-camera").ReadonlyFrameProcessor;
    /**
     * Extract MRZ from image using OCR and parse it
     */
    static extractMRZFromImage(imageUri: string): Promise<PassportMRZData | null>;
    /**
     * Comprehensive MRZ detection and extraction from OCR text
     */
    private static detectAndExtractMRZ;
    /**
     * Score how likely a line is to be MRZ Line 1
     */
    private static scoreMRZLine1;
    /**
     * Score how likely a line is to be MRZ Line 2
     */
    private static scoreMRZLine2;
    /**
     * Clean and correct MRZ line using comprehensive character mapping
     */
    private static cleanAndCorrectMRZ;
    /**
     * Parse MRZ lines according to ICAO 9303 TD3 specification
     */
    static parseMRZ(mrzLines: string[] | string): PassportMRZData;
    /**
     * Extract alphanumeric field removing filler characters
     */
    private static extractAlphanumericField;
    /**
     * Parse sex field with fallback handling
     */
    private static parseSex;
    /**
     * Format MRZ date (YYMMDD) to ISO format (YYYY-MM-DD)
     */
    private static formatMRZDate;
    /**
     * Calculate MRZ check digit according to ICAO 9303
     */
    private static calculateCheckDigit;
    /**
     * Comprehensive validation of all MRZ checksums
     */
    private static validateAllChecksums;
    /**
     * Validate MRZ format before parsing (basic format check)
     */
    static validateMRZFormat(mrzLines: string[]): boolean;
}
