import { VerifiedDocType } from '../types/extraction';
export interface DetectedCorners {
    topLeft: {
        x: number;
        y: number;
    };
    topRight: {
        x: number;
        y: number;
    };
    bottomLeft: {
        x: number;
        y: number;
    };
    bottomRight: {
        x: number;
        y: number;
    };
}
export interface DocumentDetectionResult {
    isDetected: boolean;
    corners: DetectedCorners | null;
    confidence: number;
    aspectRatio: number;
    isValidShape: boolean;
}
/**
 * Process camera frame for document detection using OpenCV
 * This function runs on the native thread (worklet)
 */
export declare function detectDocumentInFrame(frame: any, docType: VerifiedDocType, frameWidth: number, frameHeight: number): DocumentDetectionResult;
/**
 * Check if corners represent a stable detection
 */
export declare function areCornersStable(previous: DetectedCorners | null, current: DetectedCorners | null, threshold?: number): boolean;
