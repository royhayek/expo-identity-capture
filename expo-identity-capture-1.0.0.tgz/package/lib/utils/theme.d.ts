import { VerifiedDocType } from '../types/extraction';
export declare const useThemedStyles: () => {
    typography: {
        sizes: {
            xs: number;
            sm: number;
            base: number;
            lg: number;
            xl: number;
            xxl: number;
        };
        lineHeights: {
            tight: number;
            normal: number;
            relaxed: number;
        };
        fonts: {
            regular?: string;
            medium?: string;
            semibold?: string;
            bold?: string;
        };
        weights: {
            normal?: string;
            medium?: string;
            semibold?: string;
            bold?: string;
        };
    };
    spacing: {
        xs: number;
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    layout: {
        borderRadius: number;
        buttons: {
            capture: {
                width: number;
                height: number;
            };
            header: {
                width: number;
                height: number;
            };
        };
        frame: Partial<Record<VerifiedDocType, import("..").FrameDimensions>>;
        overlay: {
            opacity?: number;
        };
    };
    colors: import("..").ThemeColors;
    animation: import("..").AnimationConfig;
};
export declare const useFrameStyle: (docType: VerifiedDocType) => {
    top: string;
    left: string;
    right: string;
    height: string;
};
export declare const useProgressColors: () => {
    gradient: string[];
    background: string;
};
export declare const useButtonDimensions: (type: "capture" | "header") => {
    width: number;
    height: number;
};
export declare const useSpacing: (size: "xs" | "sm" | "md" | "lg" | "xl") => number;
export declare const createThemedStyles: (theme: any) => {
    primaryButton: {
        backgroundColor: any;
        borderRadius: any;
    };
    secondaryButton: {
        backgroundColor: any;
        borderRadius: any;
    };
    dangerButton: {
        backgroundColor: any;
        borderRadius: any;
    };
    primaryText: {
        color: any;
        fontSize: any;
        fontWeight: any;
        fontFamily: any;
    };
    headerText: {
        color: any;
        fontSize: any;
        fontWeight: any;
        fontFamily: any;
    };
    surface: {
        backgroundColor: any;
    };
    overlay: {
        backgroundColor: any;
    };
    border: {
        borderColor: any;
        borderWidth: number;
        borderRadius: any;
    };
    detectedBorder: {
        borderColor: any;
        borderWidth: number;
        borderRadius: any;
    };
};
