import { SelfieCaptureResult, SelfieCaptureOptions } from '../types';
export declare class SelfieCaptureAPI {
    private static activeCapture;
    static captureSelfie(options?: Partial<SelfieCaptureOptions>): Promise<SelfieCaptureResult>;
    private static initiateCaptureFlow;
    static isCapturing(): boolean;
    static cancelCurrentCapture(): void;
}
