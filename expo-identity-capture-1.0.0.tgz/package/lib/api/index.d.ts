export { captureAndExtract, captureMultipleDocuments, detectDocumentType, validateExtractedData } from './documentCapture';
export * from '../types/extraction';
