import { ExtractedIdResult, CaptureOptions, VerifiedDocType } from "../types/extraction";
/**
 * Main API function: Capture and extract document data
 * This is the primary interface for the package
 *
 * @param options Capture configuration options
 * @returns Promise with extracted document data
 *
 * @example
 * ```typescript
 * import { captureAndExtract } from 'expo-identity-capture';
 *
 * const result = await captureAndExtract({
 *   docHint: 'civil_id',
 *   enableQualityCheck: true,
 *   confidenceThreshold: 0.8
 * });
 *
 * console.log('Document type:', result.docType);
 * console.log('Name:', result.fields.fullNameArabic?.value);
 * console.log('ID Number:', result.fields.documentNumber?.value);
 * ```
 */
export declare function captureAndExtract(options?: CaptureOptions): Promise<ExtractedIdResult>;
/**
 * Capture and extract multiple documents (for front/back ID cards)
 *
 * @param docType Document type to extract
 * @param options Capture options
 * @returns Array of extraction results
 */
export declare function captureMultipleDocuments(docType: VerifiedDocType, options?: CaptureOptions): Promise<ExtractedIdResult[]>;
/**
 * Quick document type detection without full extraction
 * Useful for routing users to appropriate capture flows
 *
 * @param imageUri URI of document image
 * @returns Detected document type
 */
export declare function detectDocumentType(imageUri: string): Promise<VerifiedDocType>;
/**
 * Validate extracted document data
 *
 * @param result Extraction result to validate
 * @returns Validation summary
 */
export declare function validateExtractedData(result: ExtractedIdResult): {
    isValid: boolean;
    issues: string[];
    confidence: number;
};
export * from "../types/extraction";
