import React, { ReactNode } from 'react';
import { IdentityCaptureConfig } from '../types/config';
import { ConfigurableLocalizationManager } from '../localization/ConfigurableLocalization';
import { VerifiedDocType } from '../types/extraction';
interface ConfigContextType {
    config: Required<IdentityCaptureConfig>;
    updateConfig: (newConfig: Partial<IdentityCaptureConfig>) => void;
    localizationManager: ConfigurableLocalizationManager;
}
interface ConfigProviderProps {
    children: ReactNode;
    config?: IdentityCaptureConfig;
}
export declare const ConfigProvider: React.FC<ConfigProviderProps>;
export declare const useConfig: () => ConfigContextType;
export declare const useThemeConfig: () => {
    colors?: import("..").ThemeColors;
    typography?: import("..").TypographyConfig;
    layout?: import("..").LayoutConfig;
    animation?: import("..").AnimationConfig;
};
export declare const useLocalizationConfig: () => import("..").LocalizationConfig;
export declare const useBehaviorConfig: () => {
    detection?: import("..").DetectionConfig;
    camera?: import("..").CameraConfig;
    imageProcessing?: import("..").ImageProcessingConfig;
};
export declare const useDocumentConfig: () => {
    templates?: Record<VerifiedDocType, import("../types/config").DocumentTemplate>;
    validation?: import("..").ValidationConfig;
};
export declare const useLocalizedStrings: () => {
    getLocalizedString: (key: string, section: "documentLabels" | "instructions" | "alerts" | "ui", fallback: string) => string;
    getDocumentLabel: (docType: VerifiedDocType) => string;
    getInstructionText: (docType: VerifiedDocType) => string;
    getAlertMessage: (key: string) => string;
    getUIText: (key: string) => string;
    currentLanguage: string;
};
export {};
